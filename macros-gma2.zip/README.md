# Gerador de Macros grandMA2

App web para criar macros do grandMA2 com templates, preview, e exportação em texto e XML.
    