/*
Hook simples de undo/redo (serializável)
*/

import { useCallback, useMemo, useState } from "react";

export function useUndoState<T>(initial: T, opts?: { max?: number }) {
  const max = opts?.max ?? 60;
  const [past, setPast] = useState<T[]>([]);
  const [present, setPresent] = useState<T>(initial);
  const [future, setFuture] = useState<T[]>([]);

  const canUndo = past.length > 0;
  const canRedo = future.length > 0;

  const set = useCallback(
    (next: T | ((prev: T) => T)) => {
      setPresent((prev) => {
        const value = typeof next === "function" ? (next as (p: T) => T)(prev) : next;
        setPast((p) => {
          const np = [...p, prev];
          if (np.length > max) np.shift();
          return np;
        });
        setFuture([]);
        return value;
      });
    },
    [max]
  );

  const undo = useCallback(() => {
    setPast((p) => {
      if (p.length === 0) return p;
      const previous = p[p.length - 1];
      setFuture((f) => [present, ...f]);
      setPresent(previous);
      return p.slice(0, -1);
    });
  }, [present]);

  const redo = useCallback(() => {
    setFuture((f) => {
      if (f.length === 0) return f;
      const next = f[0];
      setPast((p) => [...p, present].slice(-max));
      setPresent(next);
      return f.slice(1);
    });
  }, [present, max]);

  const api = useMemo(() => ({ present, set, undo, redo, canUndo, canRedo }), [present, set, undo, redo, canUndo, canRedo]);
  return api;
}
