/*
Página principal (refeita do zero).
*/

import { useEffect, useMemo, useRef, useState } from "react";
import { nanoid } from "nanoid";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

import {
  Plus,
  Trash2,
  Copy,
  Download,
  Upload,
  Settings,
  Wand2,
  Sun,
  Moon,
  ChevronsUpDown,
} from "lucide-react";

import { useTheme } from "@/contexts/ThemeContext";
import { useIsMobile } from "@/hooks/use-mobile";
import { useUndoState } from "@/hooks/useUndoState";
import { createEmptyProject, createMacro, touchProject, type Macro, type MacroLine, type MacroProject } from "@/lib/project";
import { clearProject, loadProject, saveProject } from "@/lib/storage-v2";
import { macrosToXml, parseMacrosFromXml } from "@/lib/gma2-xml";
import { projectToText } from "@/lib/gma2-text";
import { SNIPPETS, type Snippet } from "@/lib/snippets";
import { GMA2_KEYWORDS } from "@/lib/keywords";
import { generateMacroWithAi, loadAiSettings, saveAiSettings } from "@/lib/ai";
import type { AiSettings } from "@/lib/ai";
import { CommandBuilder } from "@/components/CommandBuilder";
import { ObjectivesBuilder } from "@/components/ObjectivesBuilder";
import { PLUGIN_TEMPLATES } from "@/lib/plugin-templates";
import { RECIPES } from "@/lib/recipes";

function safeFilename(name: string) {
  const base = (name || "macro").trim() || "macro";
  return base.replaceAll(/[^a-zA-Z0-9\u00C0-\u017F _.-]/g, "_");
}

function newLine(): MacroLine {
  return { id: nanoid(), text: "", info: "", delay: 0, disabled: false };
}

function download(filename: string, content: string, mime: string) {
  if (!content.trim()) {
    toast.error("Nada para exportar");
    return;
  }
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

async function copyToClipboard(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    toast.success("Copiado");
  } catch {
    toast.error("Não consegui copiar (permissão do navegador)");
  }
}

export default function Home() {
  const isMobile = useIsMobile();
  const { theme, toggleTheme } = useTheme();

  // Projeto (com undo/redo)
  const boot = useMemo(() => {
    const saved = loadProject();
    if (saved?.macros?.length) return saved;
    return createEmptyProject();
  }, []);

  const undo = useUndoState<MacroProject>(boot, { max: 50 });
  const project = undo.present;
  const setProject = undo.set;

  const [activeMacroId, setActiveMacroId] = useState<string>(project.macros[0]?.id ?? "");
  const activeMacro = useMemo(
    () => project.macros.find((m) => m.id === activeMacroId) ?? project.macros[0],
    [project.macros, activeMacroId]
  );

  // Persistir automaticamente (debounced)
  useEffect(() => {
    const t = window.setTimeout(() => {
      try {
        saveProject(project);
      } catch {
        // ignore
      }
    }, 500);
    return () => window.clearTimeout(t);
  }, [project]);

  useEffect(() => {
    if (!activeMacroId && project.macros[0]?.id) setActiveMacroId(project.macros[0].id);
  }, [activeMacroId, project.macros]);

  function updateProject(patch: Partial<MacroProject>) {
    setProject((prev) => touchProject({ ...prev, ...patch }));
  }

  function updateMacro(macroId: string, patch: Partial<Macro>) {
    setProject((prev) => {
      const macros = prev.macros.map((m) => (m.id === macroId ? { ...m, ...patch } : m));
      return touchProject({ ...prev, macros });
    });
  }

  function addMacro() {
    setProject((prev) => {
      const maxIndex = Math.max(0, ...prev.macros.map((m) => m.index || 0));
      const m = createMacro({ name: `Macro ${maxIndex + 1}`, index: maxIndex + 1 });
      return touchProject({ ...prev, macros: [...prev.macros, m] });
    });
    toast.success("Macro adicionada");
  }

  function deleteMacro(id: string) {
    setProject((prev) => {
      const macros = prev.macros.filter((m) => m.id !== id);
      const next = touchProject({ ...prev, macros: macros.length ? macros : [createMacro({ index: 1 })] });
      return next;
    });
    setActiveMacroId((cur) => (cur === id ? project.macros.find((m) => m.id !== id)?.id ?? "" : cur));
    toast.message("Macro removida");
  }

  function addLine() {
    if (!activeMacro) return;
    updateMacro(activeMacro.id, { lines: [...activeMacro.lines, newLine()] });
  }

  function removeLine(lineId: string) {
    if (!activeMacro) return;
    updateMacro(activeMacro.id, { lines: activeMacro.lines.filter((l) => l.id !== lineId) });
  }

  function updateLine(lineId: string, patch: Partial<MacroLine>) {
    if (!activeMacro) return;
    updateMacro(activeMacro.id, {
      lines: activeMacro.lines.map((l) => (l.id === lineId ? { ...l, ...patch } : l)),
    });
  }

  // Snippets
  const [snippetCategory, setSnippetCategory] = useState<string>("Todos");
  const [snippetQuery, setSnippetQuery] = useState("");
  const filteredSnippets = useMemo(() => {
    const q = snippetQuery.trim().toLowerCase();
    return SNIPPETS.filter((s) => {
      if (snippetCategory !== "Todos" && s.category !== snippetCategory) return false;
      if (!q) return true;
      return (s.title + " " + s.description).toLowerCase().includes(q);
    });
  }, [snippetCategory, snippetQuery]);

  function applySnippet(sn: Snippet, mode: "append" | "replace") {
    if (!activeMacro) return;
    const built: MacroLine[] = sn.lines.map((l) => ({
      id: nanoid(),
      text: l.text,
      info: l.info ?? "",
      delay: l.delay ?? 0,
      disabled: l.disabled ?? false,
    }));

    updateMacro(activeMacro.id, {
      lines: mode === "replace" ? built : [...activeMacro.lines, ...built],
    });

    toast.success(mode === "replace" ? "Snippet aplicado (substituiu)" : "Snippet aplicado (adicionou)");
  }

  // Keywords
  const [kwQuery, setKwQuery] = useState("");
  const [kwCategory, setKwCategory] = useState<"all" | "object" | "function" | "helping" | "other">("all");
  const keywords = useMemo(() => {
    const q = kwQuery.trim().toLowerCase();
    return GMA2_KEYWORDS.filter((k) => {
      if (kwCategory !== "all" && k.category !== kwCategory) return false;
      if (!q) return true;
      return k.name.toLowerCase().includes(q);
    }).slice(0, 160);
  }, [kwQuery, kwCategory]);

  const [selectedLineId, setSelectedLineId] = useState<string | null>(null);
  function insertKeyword(k: string) {
    if (!activeMacro) return;

    if (selectedLineId) {
      const target = activeMacro.lines.find((l) => l.id === selectedLineId);
      if (target) {
        const base = (target.text || "").trim();
        updateLine(selectedLineId, { text: base ? `${base} ${k}` : k });
        toast.success("Inserido na linha selecionada");
        return;
      }
    }

    updateMacro(activeMacro.id, { lines: [...activeMacro.lines, { id: nanoid(), text: k, info: "", delay: 0, disabled: false }] });
    toast.success("Keyword adicionada");
  }

  // Export
  const exportXml = useMemo(() => macrosToXml(project.macros), [project.macros]);
  const exportText = useMemo(() => projectToText(project.macros), [project.macros]);

  // Import XML
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  async function onImportFile(file: File) {
    const txt = await file.text();
    const imported = parseMacrosFromXml(txt);
    if (!imported.length) {
      toast.error("Nenhuma Macro encontrada no XML");
      return;
    }
    setProject((prev) => {
      // garantir IDs únicos
      const macros: Macro[] = imported.map((m, i) => ({
        ...m,
        id: nanoid(),
        index: m.index || i + 1,
        lines: m.lines.map((l) => ({ ...l, id: nanoid() })),
      }));
      return touchProject({ ...prev, macros });
    });
    setActiveMacroId(imported[0] ? project.macros[0]?.id ?? "" : "");
    toast.success(`Importado: ${imported.length} macros`);
  }

  // IA (opcional)
  const [aiIntent, setAiIntent] = useState(
    "Crie uma macro que selecione Fixture 1 Thru 10, aplique Dimmer 100 e dê Go+ no Executor 201."
  );
  const [aiContext, setAiContext] = useState("Ex.: Front Wash = Fixture 1 Thru 10");
  const [aiAuto, setAiAuto] = useState(false);
  const [aiBusy, setAiBusy] = useState(false);
  const [aiSettings, setAiSettings] = useState<AiSettings>(() => loadAiSettings());
  const abortRef = useRef<AbortController | null>(null);

  async function runAi(apply: boolean) {
    if (!activeMacro) return;
    if (!aiSettings.apiKey.trim()) {
      toast.message("Configure a IA", { description: "Abra Configurar e cole sua chave de API." });
      return;
    }

    try {
      abortRef.current?.abort();
      abortRef.current = new AbortController();
      setAiBusy(true);

      const res = await generateMacroWithAi({
        intent: aiIntent,
        fixturesHint: aiContext,
        currentName: activeMacro.name,
        settings: aiSettings,
        signal: abortRef.current.signal,
      });

      if (apply) {
        const lines: MacroLine[] = res.lines.map((l) => ({
          id: nanoid(),
          text: l.text,
          info: l.info ?? "",
          delay: l.delay ?? 0,
          disabled: l.disabled ?? false,
        }));

        updateMacro(activeMacro.id, {
          name: (res.name || activeMacro.name).trim(),
          lines,
        });

        toast.success("IA aplicada na macro ativa");
      } else {
        toast.success("IA gerou uma sugestão (use Gerar e aplicar)");
      }

      saveAiSettings(aiSettings);
    } catch (e: any) {
      if (e?.name === "AbortError") return;
      toast.error("IA: erro", { description: String(e?.message || e) });
    } finally {
      setAiBusy(false);
    }
  }

  useEffect(() => {
    if (!aiAuto) return;
    if (!aiSettings.apiKey.trim()) return;
    const t = window.setTimeout(() => {
      runAi(true);
    }, 900);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aiAuto, aiIntent, aiContext, aiSettings.apiKey, aiSettings.baseUrl, aiSettings.modelHint, activeMacroId]);

  return (
    <div className="min-h-screen">
      <div className="surface">
        <header className="border-b bg-background/70 backdrop-blur">
          <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-xl bg-primary/15 border border-primary/20 flex items-center justify-center font-mono text-xs text-primary">
                MA2
              </div>
              <div>
                <div className="text-sm font-semibold leading-tight">Gerador de Macros grandMA2</div>
                <div className="text-xs text-muted-foreground">por Gabriel Souza Paula</div>
                <div className="text-xs text-muted-foreground">
                  Projetos • múltiplas macros • editor • automações prontas • export/import • IA opcional
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button variant="outline" size={isMobile ? "sm" : "default"} onClick={undo.undo} disabled={!undo.canUndo}>
                Desfazer {!isMobile ? <span className="ml-2 kbd">Ctrl Z</span> : null}
              </Button>
              <Button variant="outline" size={isMobile ? "sm" : "default"} onClick={undo.redo} disabled={!undo.canRedo}>
                Refazer {!isMobile ? <span className="ml-2 kbd">Ctrl Shift Z</span> : null}
              </Button>

              <Button
                size={isMobile ? "sm" : "default"}
                variant="secondary"
                onClick={() => {
                  setProject(createEmptyProject());
                  toast.message("Novo projeto", { description: "Comecei um projeto do zero." });
                }}
              >
                Novo
              </Button>

              <Button
                size={isMobile ? "sm" : "default"}
                variant="outline"
                onClick={() => {
                  clearProject();
                  toast.message("Salvo apagado", { description: "O projeto salvo neste navegador foi removido." });
                }}
              >
                Limpar salvo
              </Button>

              <Button size="icon" variant="outline" onClick={toggleTheme} aria-label="Alternar tema">
                {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-7xl px-4 py-4 sm:py-6 grid grid-cols-1 lg:grid-cols-[320px_1fr_420px] gap-4 lg:gap-5">
          {/* Painel 1: Projeto/Macros */}
          <Card className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-mono text-muted-foreground">PROJETO</div>
                <div className="text-sm font-semibold">{project.title}</div>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="icon" aria-label="Configurações">
                    <Settings className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Configurações do projeto</DialogTitle>
                    <DialogDescription>
                      Nome do projeto, import/export e preferências rápidas.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-3">
                    <div className="grid gap-2">
                      <Label>Título</Label>
                      <Input value={project.title} onChange={(e) => updateProject({ title: e.target.value })} />
                    </div>

                    <Separator />

                    <div className="grid gap-2">
                      <Label>Importar XML (Macros)</Label>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          <Upload className="mr-2 h-4 w-4" /> Selecionar arquivo
                        </Button>
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept=".xml,application/xml,text/xml"
                          className="hidden"
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (f) onImportFile(f);
                            e.currentTarget.value = "";
                          }}
                        />
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Importa Macro e Macroline do XML para o editor.
                      </div>
                    </div>

                    <Separator />

                    <div className="grid gap-2">
                      <Label>Exportar</Label>
                      <div className="flex flex-wrap gap-2">
                        <Button variant="secondary" onClick={() => copyToClipboard(exportText)}>
                          <Copy className="mr-2 h-4 w-4" /> Copiar texto
                        </Button>
                        <Button variant="outline" onClick={() => copyToClipboard(exportXml)}>
                          <Copy className="mr-2 h-4 w-4" /> Copiar XML
                        </Button>
                        <Button
                          onClick={() => download(`${safeFilename(project.title)}.xml`, exportXml, "application/xml")}
                        >
                          <Download className="mr-2 h-4 w-4" /> Baixar XML
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => download(`${safeFilename(project.title)}.txt`, exportText, "text/plain")}
                        >
                          <Download className="mr-2 h-4 w-4" /> Baixar TXT
                        </Button>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <Separator className="my-4" />

            <div className="flex items-center justify-between">
              <div className="text-xs font-mono text-muted-foreground">MACROS</div>
              <Button size="sm" onClick={addMacro}>
                <Plus className="mr-2 h-4 w-4" /> Nova
              </Button>
            </div>

            <div className="mt-3 grid gap-2">
              {project.macros.map((m) => (
                <button
                  key={m.id}
                  className={
                    "w-full text-left rounded-lg border px-3 py-2 hover:bg-muted/50 transition " +
                    (activeMacro?.id === m.id ? "border-primary/50 bg-primary/5" : "border-border")
                  }
                  onClick={() => setActiveMacroId(m.id)}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="text-sm font-semibold leading-tight">{m.name}</div>
                      <div className="text-xs text-muted-foreground">Index {m.index} • {m.lines.length} linhas</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-muted-foreground">#{m.index}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          deleteMacro(m.id);
                        }}
                        aria-label="Remover macro"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <Separator className="my-4" />

            <div className="text-xs text-muted-foreground">
              Dica: clique numa linha no editor para selecionar e inserir keywords.
            </div>
          </Card>

          {/* Painel 2: Editor */}
          <Card className="p-4">
            {!activeMacro ? (
              <div className="text-sm text-muted-foreground">Nenhuma macro selecionada.</div>
            ) : (
              <>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="text-xs font-mono text-muted-foreground">EDITOR</div>
                    <div className="mt-2 grid grid-cols-1 md:grid-cols-[1fr_140px] gap-3">
                      <div className="grid gap-2">
                        <Label>Nome</Label>
                        <Input value={activeMacro.name} onChange={(e) => updateMacro(activeMacro.id, { name: e.target.value })} />
                      </div>
                      <div className="grid gap-2">
                        <Label>Index (XML)</Label>
                        <Input
                          type="number"
                          min={1}
                          value={activeMacro.index}
                          onChange={(e) => updateMacro(activeMacro.id, { index: parseInt(e.target.value || "1", 10) || 1 })}
                        />
                      </div>
                    </div>
                  </div>

                  <Button size="sm" onClick={addLine}>
                    <Plus className="mr-2 h-4 w-4" /> Linha
                  </Button>
                </div>

                <Separator className="my-4" />

                <div className="grid gap-3">
                  {activeMacro.lines.map((l, idx) => (
                    <Card
                      key={l.id}
                      className={
                        "p-3 border " +
                        (selectedLineId === l.id ? "border-primary/40 ring-2 ring-primary/15" : "border-border")
                      }
                      onClick={() => setSelectedLineId(l.id)}
                      role="button"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="font-mono text-xs text-muted-foreground">{String(idx + 1).padStart(2, "0")}</div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            removeLine(l.id);
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="mt-2 grid gap-2">
                        <Label className="text-xs">Comando (CLI)</Label>
                        <Input
                          value={l.text}
                          onChange={(e) => updateLine(l.id, { text: e.target.value })}
                          className="font-mono"
                          placeholder='Ex.: "Go+ Executor 201"'
                        />

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                          <div className="grid gap-2">
                            <Label className="text-xs">Delay (s)</Label>
                            <Input
                              type="number"
                              step={0.1}
                              min={0}
                              value={l.delay ?? 0}
                              onChange={(e) => updateLine(l.id, { delay: parseFloat(e.target.value || "0") || 0 })}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label className="text-xs">Desabilitada</Label>
                            <Select
                              value={l.disabled ? "sim" : "nao"}
                              onValueChange={(v) => updateLine(l.id, { disabled: v === "sim" })}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="nao">Não</SelectItem>
                                <SelectItem value="sim">Sim</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="grid gap-2">
                            <Label className="text-xs">Info</Label>
                            <Input value={l.info ?? ""} onChange={(e) => updateLine(l.id, { info: e.target.value })} />
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </>
            )}
          </Card>

          {/* Painel 3: Assistentes */}
          <div className="grid gap-5">
            <Card className="p-4">
              <div className="text-xs font-mono text-muted-foreground">ASSISTENTES</div>
              <Tabs defaultValue="templates" className="mt-3">
                <TabsList className="w-full overflow-x-auto justify-start gap-2">
                  <TabsTrigger className="shrink-0" value="templates">Templates</TabsTrigger>
                  <TabsTrigger className="shrink-0" value="receitas">Receitas</TabsTrigger>
                  <TabsTrigger className="shrink-0" value="objetivos">Objetivos</TabsTrigger>
                  <TabsTrigger className="shrink-0" value="guiado">Guiado</TabsTrigger>
                  <TabsTrigger className="shrink-0" value="keywords">Keywords</TabsTrigger>
                  <TabsTrigger className="shrink-0" value="plugins">Plugins</TabsTrigger>
                  <TabsTrigger className="shrink-0" value="ia">IA</TabsTrigger>
                </TabsList>

                <TabsContent value="templates" className="mt-4">
                  <div className="grid gap-2">
                    <Input value={snippetQuery} onChange={(e) => setSnippetQuery(e.target.value)} placeholder="Buscar snippet..." />
                    <Select value={snippetCategory} onValueChange={setSnippetCategory}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Todos">Todos</SelectItem>
                        <SelectItem value="Seleção">Seleção</SelectItem>
                        <SelectItem value="Executor">Executor</SelectItem>
                        <SelectItem value="Page">Page</SelectItem>
                        <SelectItem value="Atributos">Atributos</SelectItem>
                        <SelectItem value="Timing">Timing</SelectItem>
                        <SelectItem value="Store/Update">Store/Update</SelectItem>
                        <SelectItem value="Utilidades">Utilidades</SelectItem>
                      </SelectContent>
                    </Select>

                    <div className="max-h-[360px] overflow-auto rounded-lg border border-border">
                      <div className="p-2 grid gap-2">
                        {filteredSnippets.map((sn) => (
                          <Card key={sn.id} className="p-3">
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <div className="text-sm font-semibold">{sn.title}</div>
                                <div className="text-xs text-muted-foreground">{sn.category} • {sn.description}</div>
                              </div>
                              <ChevronsUpDown className="h-4 w-4 text-muted-foreground" />
                            </div>
                            <div className="mt-2 flex gap-2">
                              <Button size="sm" onClick={() => applySnippet(sn, "append")}>
                                Adicionar
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => applySnippet(sn, "replace")}>
                                Substituir
                              </Button>
                            </div>
                          </Card>
                        ))}
                        {filteredSnippets.length === 0 ? (
                          <div className="text-sm text-muted-foreground p-3">Nenhum snippet encontrado.</div>
                        ) : null}
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground">
                      Templates são ações comuns com placeholders. Clique em <span className="font-semibold">Adicionar</span> e use.
                      Depois substitua <span className="font-mono">&lt;FIXTURES&gt;</span>, <span className="font-mono">&lt;EXEC&gt;</span>, etc.
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="receitas" className="mt-4">
                  <div className="grid gap-2">
                    <div className="text-xs text-muted-foreground">
                      Receitas são automações prontas (multi-linha). Clique em <span className="font-semibold">Inserir</span> e ajuste os placeholders.
                    </div>

                    <div className="max-h-[380px] overflow-auto rounded-lg border border-border">
                      <div className="p-2 grid gap-2">
                        {RECIPES.map((r) => (
                          <Card key={r.id} className="p-3">
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <div className="text-sm font-semibold">{r.title}</div>
                                <div className="text-xs text-muted-foreground">{r.category} • {r.description}</div>
                              </div>
                            </div>

                            <pre className="mt-2 rounded-lg border border-border bg-muted p-3 font-mono text-xs overflow-auto">
{r.lines.map((l) => `${l.delay && l.delay > 0 ? `[delay ${l.delay}s] ` : ""}${l.text}`).join("\n")}
                            </pre>

                            <div className="mt-2 flex gap-2">
                              <Button
                                size="sm"
                                onClick={() => {
                                  if (!activeMacro) return;
                                  const toAdd = r.lines.map((x) => ({
                                    id: nanoid(),
                                    text: x.text,
                                    info: x.info || "",
                                    delay: x.delay || 0,
                                    disabled: !!x.disabled,
                                  }));
                                  updateMacro(activeMacro.id, { lines: [...activeMacro.lines, ...toAdd] });
                                  toast.success("Receita inserida");
                                }}
                              >
                                <Plus className="mr-2 h-4 w-4" /> Inserir
                              </Button>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground">
                      Exemplos incluídos: Go+, Delay na linha, Fade, Store/Label, Update, pre-show clean e receita interativa com <span className="font-mono">@</span>.
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="objetivos" className="mt-4">
                  <ObjectivesBuilder
                    onInsert={(built) => {
                      if (!activeMacro) return;
                      const toAdd = built
                        .filter((x) => (x.text || "").trim().length > 0)
                        .map((x) => ({
                          id: nanoid(),
                          text: x.text,
                          info: x.info || "",
                          delay: x.delay || 0,
                          disabled: !!x.disabled,
                        }));
                      if (!toAdd.length) return;
                      updateMacro(activeMacro.id, { lines: [...activeMacro.lines, ...toAdd] });
                      toast.success("Objetivo aplicado");
                    }}
                  />
                </TabsContent>

                <TabsContent value="guiado" className="mt-4">
                  <CommandBuilder
                    onInsert={(built) => {
                      if (!activeMacro) return;
                      const toAdd = built
                        .filter((x) => (x.text || "").trim().length > 0)
                        .map((x) => ({
                          id: nanoid(),
                          text: x.text,
                          info: x.info || "",
                          delay: 0,
                          disabled: false,
                        }));
                      if (!toAdd.length) return;
                      updateMacro(activeMacro.id, { lines: [...activeMacro.lines, ...toAdd] });
                      toast.success("Linhas inseridas");
                    }}
                  />
                </TabsContent>

                <TabsContent value="keywords" className="mt-4">
                  <div className="grid gap-2">
                    <Input value={kwQuery} onChange={(e) => setKwQuery(e.target.value)} placeholder="Buscar keyword... (Store, Go, MAtricks)" />
                    <Select value={kwCategory} onValueChange={(v) => setKwCategory(v as any)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todas</SelectItem>
                        <SelectItem value="function">Function</SelectItem>
                        <SelectItem value="object">Object</SelectItem>
                        <SelectItem value="helping">Helping</SelectItem>
                        <SelectItem value="other">Outras</SelectItem>
                      </SelectContent>
                    </Select>

                    <div className="max-h-[360px] overflow-auto rounded-lg border border-border">
                      <div className="p-2 grid gap-1">
                        {keywords.map((k) => (
                          <div key={k.url} className="flex items-center justify-between gap-2 rounded-md px-2 py-1 hover:bg-muted/50">
                            <button className="font-mono text-xs text-left hover:text-primary" onClick={() => insertKeyword(k.name)}>
                              {k.name}
                            </button>
                            <a className="text-xs text-muted-foreground hover:text-foreground" href={k.url} target="_blank" rel="noreferrer">
                              docs
                            </a>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground">
                      Selecione uma linha no editor e clique numa keyword para inserir.
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="plugins" className="mt-4">
                  <div className="grid gap-3">
                    <Card className="p-3">
                      <div className="text-sm font-semibold">Plugins (Lua) — automações avançadas</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        No grandMA2, plugins são escritos em <span className="font-mono">Lua 5.3</span> e rodam com o comando <span className="font-mono">Plugin &lt;ID&gt;</span> (default é Go+).
                        Após editar, normalmente você precisa <span className="font-mono">Reload</span> / <span className="font-mono">ReloadPlugins</span> para recarregar o engine.
                      </div>
                      <Separator className="my-3" />
                      <div className="text-xs text-muted-foreground">
                        Fluxo oficial (resumo): <span className="font-mono">System → Plugin</span> → <span className="font-mono">Edit</span> em um slot → escrever Lua → <span className="font-mono">Save</span> → <span className="font-mono">Reload</span>.
                      </div>
                    </Card>

                    <div className="max-h-[380px] overflow-auto rounded-lg border border-border">
                      <div className="p-2 grid gap-2">
                        {PLUGIN_TEMPLATES.map((p) => (
                          <Card key={p.id} className="p-3">
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <div className="text-sm font-semibold">{p.title}</div>
                                <div className="text-xs text-muted-foreground">{p.description}</div>
                              </div>
                            </div>

                            <pre className="mt-2 rounded-lg border border-border bg-muted p-3 font-mono text-xs overflow-auto">{p.lua}</pre>

                            <div className="mt-2 flex flex-wrap gap-2">
                              <Button size="sm" variant="secondary" onClick={() => copyToClipboard(p.lua)}>
                                <Copy className="mr-2 h-4 w-4" /> Copiar Lua
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => download(`${safeFilename(p.title)}.lua`, p.lua, "text/plain")}
                              >
                                <Download className="mr-2 h-4 w-4" /> Baixar .lua
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => {
                                  if (!activeMacro) return;
                                  // cria um pequeno “macro template” para rodar o plugin
                                  const lines = [
                                    { id: nanoid(), text: "ReloadPlugins", info: "Recarrega engine Lua (opcional)" },
                                    { id: nanoid(), text: "Plugin <ID>", info: p.runHint },
                                  ].map((l) => ({ ...l, delay: 0, disabled: false }));
                                  updateMacro(activeMacro.id, { lines: [...activeMacro.lines, ...lines] });
                                  toast.success("Inseri um template de macro para rodar plugin");
                                }}
                              >
                                <Plus className="mr-2 h-4 w-4" /> Inserir Macro Runner
                              </Button>
                            </div>

                            <div className="mt-2 text-xs text-muted-foreground">
                              Dica: no onPC, existe um exemplo <span className="font-mono">plugin_1.lua</span> na pasta de plugins. Você pode usar como referência.
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>

                    <Card className="p-3">
                      <div className="text-xs font-mono text-muted-foreground">COMANDOS ÚTEIS</div>
                      <div className="mt-2 grid gap-1 text-xs text-muted-foreground">
                        <div><span className="font-mono">Plugin 2</span> — executa o plugin 2</div>
                        <div><span className="font-mono">Assign Plugin 2/name=\"Meu Plugin\"</span> — renomeia</div>
                        <div><span className="font-mono">ReloadPlugins</span> — reinicia o engine Lua</div>
                        <div><span className="font-mono">Lua \"gma.feedback('hello')\"</span> — executa Lua direto na linha</div>
                      </div>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="ia" className="mt-4">
                  <div className="grid gap-3">
                    <Card className="p-3">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="text-sm font-semibold">Assistente de IA (opcional)</div>
                          <div className="text-xs text-muted-foreground">
                            Usa uma API compatível com OpenAI. A chave fica só no seu navegador.
                          </div>
                        </div>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Settings className="mr-2 h-4 w-4" /> Configurar
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Configuração de IA</DialogTitle>
                              <DialogDescription>Base URL + chave de API + model opcional.</DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-3">
                              <div className="grid gap-2">
                                <Label>Base URL</Label>
                                <Input value={aiSettings.baseUrl} onChange={(e) => setAiSettings((s) => ({ ...s, baseUrl: e.target.value }))} />
                              </div>
                              <div className="grid gap-2">
                                <Label>Chave de API</Label>
                                <Input type="password" value={aiSettings.apiKey} onChange={(e) => setAiSettings((s) => ({ ...s, apiKey: e.target.value }))} />
                              </div>
                              <div className="grid gap-2">
                                <Label>Model (opcional)</Label>
                                <Input value={aiSettings.modelHint || ""} onChange={(e) => setAiSettings((s) => ({ ...s, modelHint: e.target.value }))} />
                              </div>
                              <Button
                                onClick={() => {
                                  saveAiSettings(aiSettings);
                                  toast.success("Configuração salva");
                                }}
                              >
                                Salvar
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>

                      <Separator className="my-3" />

                      <div className="grid gap-2">
                        <Label>O que a macro deve fazer?</Label>
                        <Textarea value={aiIntent} onChange={(e) => setAiIntent(e.target.value)} className="min-h-[120px]" />
                      </div>
                      <div className="grid gap-2">
                        <Label>Contexto (opcional)</Label>
                        <Input value={aiContext} onChange={(e) => setAiContext(e.target.value)} />
                      </div>

                      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mt-2">
                        <div className="flex items-center gap-3">
                          <Switch checked={aiAuto} onCheckedChange={setAiAuto} />
                          <div>
                            <div className="text-sm">Tempo real</div>
                            <div className="text-xs text-muted-foreground">Regera e aplica automaticamente (debounce).</div>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button onClick={() => runAi(true)} disabled={aiBusy}>
                            <Wand2 className="mr-2 h-4 w-4" /> {aiBusy ? "Gerando..." : "Gerar e aplicar"}
                          </Button>
                          <Button
                            variant="outline"
                            onClick={() => {
                              setAiAuto(false);
                              abortRef.current?.abort();
                              toast.message("IA pausada");
                            }}
                          >
                            Pausar
                          </Button>
                        </div>
                      </div>
                    </Card>

                    <div className="text-xs text-muted-foreground">
                      Sugestão: descreva em passos: ClearAll → Fixture 1 Thru 10 → Attribute Dimmer At 100 → Go+ Executor 201.
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </Card>

            <Card className="p-4">
              <div className="text-xs font-mono text-muted-foreground">EXPORT RÁPIDO (macro ativa)</div>
              <div className="mt-2 flex flex-wrap gap-2">
                <Button
                  variant="secondary"
                  onClick={() => {
                    if (!activeMacro) return;
                    copyToClipboard(projectToText([activeMacro]));
                  }}
                >
                  <Copy className="mr-2 h-4 w-4" /> Copiar texto
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    if (!activeMacro) return;
                    copyToClipboard(macrosToXml([activeMacro]));
                  }}
                >
                  <Copy className="mr-2 h-4 w-4" /> Copiar XML
                </Button>
                <Button
                  onClick={() => {
                    if (!activeMacro) return;
                    download(`${safeFilename(activeMacro.name)}.xml`, macrosToXml([activeMacro]), "application/xml");
                  }}
                >
                  <Download className="mr-2 h-4 w-4" /> Baixar XML
                </Button>
              </div>

              <Separator className="my-4" />

              <div className="text-xs text-muted-foreground">
                No MA2, você costuma importar via Setup → Import/Export → Import → Macro, ou pela linha:
              </div>
              <pre className="mt-2 rounded-lg border border-border bg-muted p-3 font-mono text-xs overflow-auto">
CD Macro
Import "NomeDoArquivo"   // sem .xml
              </pre>
            </Card>
          </div>
        </main>

        <footer className="mx-auto max-w-7xl px-4 pb-10 text-xs text-muted-foreground">
          <Separator className="my-6" />
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <span className="text-foreground">Criado por Gabriel Souza Paula</span>
              <span className="mx-2">•</span>
              <span>
                Feito com ajuda do <span className="text-foreground">AnyGen</span> (assistente de IA)
              </span>
              <span className="mx-2">•</span>
              <span>
                App web estático (funciona online/offline). IA opcional: chave fica no seu navegador.
              </span>
            </div>
            <div className="font-mono">v2</div>
          </div>
        </footer>
      </div>
    </div>
  );
}
