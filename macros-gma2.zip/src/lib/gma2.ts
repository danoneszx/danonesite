/*
DESIGN: "Console Brutal" (grandMA vibe)
Arquivo: gma2.ts
- Modelos + templates + exportadores (texto e XML)
- XML compatível com export/import de macro do MA2 (estrutura MA/Macro/Macroline)
*/

export type TemplateId =
  | "fixture_select"
  | "fixture_clear"
  | "executor_go"
  | "executor_off"
  | "page_go"
  | "set_dimmer"
  | "set_color_rgb"
  | "timing_fade";

export interface MacroLine {
  id: string;
  /** índice 1-based (definido no Home) */
  index?: number;
  text: string;
  info?: string;
  delay?: number; // segundos
  disabled?: boolean;
}

export interface MacroDoc {
  meta?: {
    createdAtIso?: string;
    updatedAtIso?: string;
    source?: "manual" | "template" | "ai";
  };
  macro: {
    name: string;
    index: number;
    lines: MacroLine[];
  };
}

export const TEMPLATE_OPTIONS: Array<{ id: TemplateId; label: string }> = [
  { id: "fixture_select", label: "Seleção: Fixture <FIXTURES>" },
  { id: "fixture_clear", label: "Seleção: ClearAll" },
  { id: "executor_go", label: "Executor: Go+ Executor <EXEC>" },
  { id: "executor_off", label: "Executor: Off Executor <EXEC>" },
  { id: "page_go", label: "Página: Page <PAGE>" },
  { id: "set_dimmer", label: "Atributo: Dimmer At <VAL>" },
  { id: "set_color_rgb", label: "Atributo: ColorRGB At <R> <G> <B>" },
  { id: "timing_fade", label: "Timing: Fade <T>" },
];

function escXml(s: string) {
  return s
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&apos;");
}

function fmtDelay(n: number) {
  const v = Number.isFinite(n) ? n : 0;
  if (v <= 0) return null;
  // MA2 export costuma usar ponto como separador
  return String(Math.round(v * 1000) / 1000);
}

export function buildLinesFromTemplate(t: TemplateId): Omit<MacroLine, "id">[] {
  switch (t) {
    case "fixture_select":
      return [{ text: "Fixture <FIXTURES>", info: "Ex.: 1 Thru 10", delay: 0, disabled: false }];
    case "fixture_clear":
      return [{ text: "ClearAll", info: "Limpa seleção/valores", delay: 0, disabled: false }];
    case "executor_go":
      return [{ text: "Go+ Executor <EXEC>", info: "Ex.: 201", delay: 0, disabled: false }];
    case "executor_off":
      return [{ text: "Off Executor <EXEC>", info: "Ex.: 201", delay: 0, disabled: false }];
    case "page_go":
      return [{ text: "Page <PAGE>", info: "Ex.: 1", delay: 0, disabled: false }];
    case "set_dimmer":
      return [
        { text: "Attribute \"Dimmer\" At <VAL>", info: "Ex.: 100", delay: 0, disabled: false },
      ];
    case "set_color_rgb":
      return [
        {
          text: "Attribute \"ColorRGB\" At <R> <G> <B>",
          info: "Ex.: 100 0 0",
          delay: 0,
          disabled: false,
        },
      ];
    case "timing_fade":
      return [{ text: "Fade <T>", info: "Ex.: 0.5", delay: 0, disabled: false }];
    default:
      return [];
  }
}

export function macroToClipboardText(doc: MacroDoc) {
  const header = [
    `# Macro: ${doc.macro.name}`,
    `# (Texto de referência/colagem — ajuste conforme seu workflow no grandMA2)`,
    `# Linhas:`,
  ].join("\n");

  const body = doc.macro.lines
    .filter((l) => (l.text ?? "").trim().length > 0)
    .map((l, i) => {
      const n = i + 1;
      const flags = [l.disabled ? "DISABLED" : null, l.delay && l.delay > 0 ? `DELAY=${l.delay}s` : null]
        .filter(Boolean)
        .join(" ");
      const prefix = flags ? `; ${flags}` : "";
      const info = l.info ? ` ; info: ${l.info}` : "";
      return `${String(n).padStart(2, "0")}: ${l.text}${prefix}${info}`;
    })
    .join("\n");

  return `${header}\n${body}\n`;
}

export function macroToXml(doc: MacroDoc) {
  // Estrutura baseada em exemplos públicos de export/import de macros (MA/Macro/Macroline)
  // Macro.index e Macroline.index aqui são 0-based no XML (comum em exportações)
  const macroIndex0 = Math.max(0, Math.floor(doc.macro.index - 1));

  const linesXml = doc.macro.lines
    .filter((l) => (l.text ?? "").trim().length > 0)
    .map((l, i) => {
      const lineIndex0 = i;
      const delay = fmtDelay(l.delay ?? 0);
      const disabled = l.disabled ? "true" : null;

      const attrs = [
        `index=\"${lineIndex0}\"`,
        delay ? `delay=\"${delay}\"` : null,
        disabled ? `disabled=\"${disabled}\"` : null,
      ]
        .filter(Boolean)
        .join(" ");

      const info = (l.info ?? "").trim();

      return [
        `    <Macroline ${attrs}>`,
        `      <text>${escXml(l.text ?? "")}</text>`,
        info ? `      <info>${escXml(info)}</info>` : null,
        `    </Macroline>`,
      ]
        .filter(Boolean)
        .join("\n");
    })
    .join("\n");

  return [
    `<?xml version=\"1.0\" encoding=\"utf-8\"?>`,
    `<MA>`,
    `  <Macro index=\"${macroIndex0}\" name=\"${escXml(doc.macro.name)}\">`,
    linesXml || "",
    `  </Macro>`,
    `</MA>`,
    "",
  ].join("\n");
}
