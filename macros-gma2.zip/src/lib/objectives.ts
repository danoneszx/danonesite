/*
Macros por objetivo: geradores que montam linhas automaticamente.

Obs:
- Mantemos o output conservador e editável.
- Alguns objetivos dependem do show (IDs de executors, sequences, etc.).
  Por isso usamos placeholders e campos simples.
*/

export type ObjectiveId = "pre_show" | "blackout" | "chase";

export type Objective = {
  id: ObjectiveId;
  title: string;
  description: string;
};

export const OBJECTIVES: Objective[] = [
  {
    id: "pre_show",
    title: "Pre-Show (Reset seguro)",
    description: "Coloca a mesa em um estado conhecido: desliga modos, limpa seleção e ajusta masters básicos.",
  },
  {
    id: "blackout",
    title: "Blackout (rápido e reversível)",
    description: "Cria linhas para blackout (via keyword Blackout/SpecialMaster). Ajuste para seu workflow.",
  },
  {
    id: "chase",
    title: "Chase (playback rápido)",
    description: "Monta uma macro para disparar/ajustar um chase (executor), com fade e delays opcionais.",
  },
];

export type ObjectiveInput =
  | {
      id: "pre_show";
      includeClearAll: boolean;
      includeResetDmxSelection: boolean;
      includeOffModes: boolean;
      masterGrandAt?: number; // 0-100
    }
  | {
      id: "blackout";
      method: "Blackout keyword" | "SpecialMaster Grandmaster";
      value: "On" | "Off" | "Toggle";
    }
  | {
      id: "chase";
      executor: string; // ex 201
      fadeSeconds: number;
      initialDelay: number;
      action: "Go+" | "Off" | "Toggle";
    };

export type ObjectiveLine = { text: string; info?: string; delay?: number; disabled?: boolean };

export function buildObjectiveLines(input: ObjectiveInput): ObjectiveLine[] {
  switch (input.id) {
    case "pre_show": {
      const lines: ObjectiveLine[] = [];
      if (input.includeOffModes) {
        lines.push({ text: "Off Blind", info: "Modo" });
        lines.push({ text: "Off Highlight", info: "Modo" });
        lines.push({ text: "Off Solo", info: "Modo" });
      }
      if (input.includeClearAll) {
        lines.push({ text: "ClearAll", info: "Limpa (opcional)", disabled: true });
      }
      if (input.includeResetDmxSelection) {
        lines.push({ text: "ResetDmxSelection", info: "Seleção DMX" });
      }
      if (typeof input.masterGrandAt === "number" && Number.isFinite(input.masterGrandAt)) {
        const v = Math.max(0, Math.min(100, Math.round(input.masterGrandAt)));
        lines.push({ text: `SpecialMaster \"grandmaster\".\"Grand\" At ${v}`, info: "Master" });
      }
      return lines;
    }

    case "blackout": {
      if (input.method === "Blackout keyword") {
        if (input.value === "Toggle") return [{ text: "Toggle Blackout", info: "Blackout" }];
        return [{ text: input.value === "On" ? "Blackout On" : "Blackout Off", info: "Blackout" }];
      }
      // Alternativa: Grandmaster at 0/100 (não é o mesmo blackout, mas útil em alguns shows)
      if (input.value === "Toggle") {
        return [
          { text: "Toggle SpecialMaster \"grandmaster\".\"Grand\"", info: "Master" },
        ];
      }
      return [
        {
          text:
            input.value === "On"
              ? "SpecialMaster \"grandmaster\".\"Grand\" At 0"
              : "SpecialMaster \"grandmaster\".\"Grand\" At 100",
          info: "Master",
        },
      ];
    }

    case "chase": {
      const ex = (input.executor || "").trim() || "<EXEC>";
      const fade = Number.isFinite(input.fadeSeconds) ? input.fadeSeconds : 0;
      const startDelay = Number.isFinite(input.initialDelay) ? input.initialDelay : 0;
      const lines: ObjectiveLine[] = [];
      if (fade && fade > 0) lines.push({ text: `Fade ${fade}`, info: "Timing" });

      if (input.action === "Go+") {
        lines.push({ text: `Go+ Executor ${ex}`, info: "Chase" , delay: startDelay });
      } else if (input.action === "Off") {
        lines.push({ text: `Off Executor ${ex}`, info: "Chase", delay: startDelay });
      } else {
        lines.push({ text: `Toggle Executor ${ex}`, info: "Chase", delay: startDelay });
      }

      return lines;
    }

    default:
      return [];
  }
}
