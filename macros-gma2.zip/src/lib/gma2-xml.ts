/*
Import/Export XML de macros (grandMA2)
- Estrutura baseada em exportações públicas: <MA><Macro index name><Macroline index delay disabled><text/><info/></Macroline>...
- Suporta exportar múltiplas macros no mesmo arquivo
*/

import type { Macro, MacroLine } from "@/lib/project";

function escXml(s: string) {
  return s
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&apos;");
}

function fmtDelay(n: number) {
  const v = Number.isFinite(n) ? n : 0;
  if (v <= 0) return null;
  return String(Math.round(v * 1000) / 1000);
}

export function macroToXml(m: Macro) {
  const macroIndex0 = Math.max(0, Math.floor((m.index || 1) - 1));
  const lines = (m.lines || []).filter((l) => (l.text ?? "").trim().length > 0);

  const linesXml = lines
    .map((l, i) => lineToXml(l, i))
    .join("\n");

  return [
    `  <Macro index="${macroIndex0}" name="${escXml(m.name || "Macro")}">`,
    linesXml,
    `  </Macro>`,
  ]
    .filter(Boolean)
    .join("\n");
}

function lineToXml(l: MacroLine, lineIndex0: number) {
  const delay = fmtDelay(l.delay ?? 0);
  const disabled = l.disabled ? "true" : null;
  const attrs = [
    `index="${lineIndex0}"`,
    delay ? `delay="${delay}"` : null,
    disabled ? `disabled="${disabled}"` : null,
  ]
    .filter(Boolean)
    .join(" ");

  const info = (l.info ?? "").trim();

  return [
    `    <Macroline ${attrs}>`,
    `      <text>${escXml(l.text ?? "")}</text>`,
    info ? `      <info>${escXml(info)}</info>` : null,
    `    </Macroline>`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function macrosToXml(macros: Macro[]) {
  const content = macros
    .slice()
    .sort((a, b) => (a.index || 1) - (b.index || 1))
    .map((m) => macroToXml(m))
    .join("\n");

  return [
    `<?xml version="1.0" encoding="utf-8"?>`,
    `<MA>`,
    content,
    `</MA>`,
    "",
  ].join("\n");
}

export function parseMacrosFromXml(xml: string): Macro[] {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, "application/xml");

  // detectar erros de parse
  const err = doc.getElementsByTagName("parsererror")[0];
  if (err) {
    throw new Error("XML inválido (parsererror)");
  }

  const macros: Macro[] = [];
  const macroEls = Array.from(doc.getElementsByTagName("Macro"));

  for (const me of macroEls) {
    const idx0 = parseInt(me.getAttribute("index") || "0", 10);
    const name = me.getAttribute("name") || "Macro";

    const lineEls = Array.from(me.getElementsByTagName("Macroline"));
    const lines: MacroLine[] = lineEls
      .map((le) => {
        const textEl = le.getElementsByTagName("text")[0];
        const infoEl = le.getElementsByTagName("info")[0];
        const text = textEl?.textContent ?? "";
        const info = infoEl?.textContent ?? "";
        const delay = parseFloat(le.getAttribute("delay") || "0");
        const disabled = (le.getAttribute("disabled") || "").toLowerCase() === "true";
        return {
          id: crypto.randomUUID(),
          text,
          info,
          delay: Number.isFinite(delay) ? delay : 0,
          disabled,
        };
      })
      .filter((l) => (l.text ?? "").trim().length > 0);

    macros.push({
      id: crypto.randomUUID(),
      name,
      index: idx0 + 1,
      lines,
    });
  }

  return macros;
}
