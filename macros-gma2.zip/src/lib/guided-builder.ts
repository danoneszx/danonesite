/*
Editor guiado: transforma campos em linhas de comando do grandMA2.
Observação: a sintaxe do MA2 tem variações e opções. Aqui focamos no “core”
mais usado (Store/Update/Go/Fade) e mantemos o output explícito.
*/

export type GuidedAction = "Go" | "Fade" | "Store" | "Update";

export type GoAction = {
  kind: "Go";
  variant: "Go" | "Go+" | "GoBack";
  target: "Executor" | "Sequence";
  executor?: string; // ex.: 201 ou 201.1
  sequence?: string; // ex.: 1
  cue?: string; // ex.: 10
};

export type FadeAction = {
  kind: "Fade";
  seconds: number;
};

export type StoreAction = {
  kind: "Store";
  object: "Group" | "Preset" | "Sequence" | "Macro";
  id: string; // ex.: 10 ou 4.1
  overwrite: boolean; // /o
  merge: boolean; // /m (se aplicável)
  label?: string; // "nome" opcional
};

export type UpdateAction = {
  kind: "Update";
  object: "Group" | "Preset" | "Sequence";
  id: string;
  merge: boolean; // /m
};

export type GuidedActionState = GoAction | FadeAction | StoreAction | UpdateAction;

export function buildGuidedLines(a: GuidedActionState): Array<{ text: string; info?: string }> {
  switch (a.kind) {
    case "Fade": {
      const t = Number.isFinite(a.seconds) ? a.seconds : 0;
      return [{ text: `Fade ${t}`.trim(), info: "Timing" }];
    }

    case "Go": {
      const v = a.variant;
      if (a.target === "Executor") {
        const ex = (a.executor || "").trim() || "<EXEC>";
        return [{ text: `${v} Executor ${ex}`.trim(), info: "Playback" }];
      }
      const seq = (a.sequence || "").trim() || "<SEQ>";
      if (a.cue && a.cue.trim()) {
        return [{ text: `${v} Sequence ${seq} Cue ${a.cue.trim()}`.trim(), info: "Playback" }];
      }
      return [{ text: `${v} Sequence ${seq}`.trim(), info: "Playback" }];
    }

    case "Store": {
      const id = (a.id || "").trim() || "<ID>";
      const parts: string[] = ["Store", a.object, id];
      if (a.label && a.label.trim()) {
        // Muitas áreas aceitam Label separadamente; aqui oferecemos nome como "Label" depois.
        // Preferimos manter simples e não forçar syntax específica.
      }
      const opts: string[] = [];
      if (a.overwrite) opts.push("/o");
      if (a.merge) opts.push("/m");
      const cmd = [...parts, ...opts].join(" ").trim();

      const extra: Array<{ text: string; info?: string }> = [];
      if (a.label && a.label.trim()) {
        extra.push({ text: `Label ${a.object} ${id} "${a.label.trim()}"`, info: "Nome" });
      }
      return [{ text: cmd, info: "Store" }, ...extra];
    }

    case "Update": {
      const id = (a.id || "").trim() || "<ID>";
      const opts: string[] = [];
      if (a.merge) opts.push("/m");
      return [{ text: [`Update`, a.object, id, ...opts].join(" ").trim(), info: "Update" }];
    }

    default:
      return [];
  }
}
