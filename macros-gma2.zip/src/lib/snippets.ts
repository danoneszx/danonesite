/*
Biblioteca de snippets “de verdade” (ações comuns) com placeholders.
Isso é o que dá produtividade: clique e insere comando pronto.
*/

export type Snippet = {
  id: string;
  title: string;
  category:
    | "Seleção"
    | "Executor"
    | "Page"
    | "Atributos"
    | "Timing"
    | "Store/Update"
    | "Utilidades";
  description: string;
  lines: Array<{ text: string; info?: string; delay?: number; disabled?: boolean }>;
};

export const SNIPPETS: Snippet[] = [
  {
    id: "sel-clearall",
    title: "ClearAll (opcional)",
    category: "Seleção",
    description: "Limpa seleção/valores. Útil como primeira linha (pode ficar desabilitada).",
    lines: [{ text: "ClearAll", info: "(opcional)", disabled: true }],
  },
  {
    id: "sel-fixture",
    title: "Selecionar Fixtures",
    category: "Seleção",
    description: "Seleciona um range de fixtures.",
    lines: [{ text: "Fixture <FIXTURES>", info: "Ex.: 1 Thru 10" }],
  },
  {
    id: "sel-group",
    title: "Selecionar Group",
    category: "Seleção",
    description: "Seleciona um grupo.",
    lines: [{ text: "Group <GROUP>", info: "Ex.: 1" }],
  },
  {
    id: "page",
    title: "Ir para Page",
    category: "Page",
    description: "Muda a página ativa.",
    lines: [{ text: "Page <PAGE>", info: "Ex.: 1" }],
  },
  {
    id: "exec-go",
    title: "Go+ Executor",
    category: "Executor",
    description: "Dispara executor.",
    lines: [{ text: "Go+ Executor <EXEC>", info: "Ex.: 201" }],
  },
  {
    id: "exec-off",
    title: "Off Executor",
    category: "Executor",
    description: "Desliga executor.",
    lines: [{ text: "Off Executor <EXEC>", info: "Ex.: 201" }],
  },
  {
    id: "attr-dimmer",
    title: "Dimmer",
    category: "Atributos",
    description: "Define dimmer via Attribute.",
    lines: [{ text: "Attribute \"Dimmer\" At <VAL>", info: "Ex.: 100" }],
  },
  {
    id: "attr-colorrgb",
    title: "ColorRGB",
    category: "Atributos",
    description: "Define cor RGB (placeholder).",
    lines: [{ text: "Attribute \"ColorRGB\" At <R> <G> <B>", info: "Ex.: 100 0 0" }],
  },
  {
    id: "timing-fade",
    title: "Fade",
    category: "Timing",
    description: "Define fade antes do comando seguinte.",
    lines: [{ text: "Fade <T>", info: "Ex.: 0.5" }],
  },
  {
    id: "store-group",
    title: "Store Group",
    category: "Store/Update",
    description: "Armazena o grupo atual.",
    lines: [{ text: "Store Group <GROUP> /o", info: "Ex.: 10" }],
  },
  {
    id: "util-wait",
    title: "Wait/Delay na linha",
    category: "Utilidades",
    description: "Sugestão: use delay quando precisa aguardar o console processar.",
    lines: [{ text: "(linha anterior)" , info: "Ajuste o campo Delay desta linha", disabled: true }],
  },
];
