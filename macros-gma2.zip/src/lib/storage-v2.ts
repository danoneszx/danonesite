/*
Persistência local do projeto
*/

import type { MacroProject } from "@/lib/project";

const KEY = "gma2-macro-project:v2";

export function saveProject(p: MacroProject) {
  localStorage.setItem(KEY, JSON.stringify(p));
}

export function loadProject(): MacroProject | null {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as MacroProject;
  } catch {
    return null;
  }
}

export function clearProject() {
  localStorage.removeItem(KEY);
}
