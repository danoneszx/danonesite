/*
Receitas = automações prontas (multi-linha) para inserir em 1 clique.
Foco: blocos úteis que combinam Go+/Delay/Fade/Store/Update, etc.

Observação importante:
- O grandMA2 tem vários jeitos de fazer a mesma coisa. Aqui mantemos receitas
  conservadoras, fáceis de ajustar (com placeholders).
- Delay aqui é o delay da linha (coluna Wait/Delay). No nosso editor, isso é o campo delay.
*/

export type Recipe = {
  id: string;
  title: string;
  category: "Playback" | "Timing" | "Store/Update" | "Setup" | "Util";
  description: string;
  lines: Array<{ text: string; info?: string; delay?: number; disabled?: boolean }>;
};

export const RECIPES: Recipe[] = [
  {
    id: "go-plus-with-fade",
    title: "Go+ com Fade (antes)",
    category: "Playback",
    description: "Define Fade e dispara um Executor. Ajuste <EXEC> e o tempo.",
    lines: [
      { text: "Fade <T>", info: "Ex.: 0.5" },
      { text: "Go+ Executor <EXEC>", info: "Ex.: 201" },
    ],
  },
  {
    id: "go-plus-delayed",
    title: "Go+ com Delay na linha",
    category: "Playback",
    description: "Dispara executor após esperar X segundos (delay no macroline).",
    lines: [
      { text: "Go+ Executor <EXEC>", info: "Ex.: 201", delay: 0.5 },
    ],
  },
  {
    id: "burst-go-sequence",
    title: "Disparar sequência de executors (serial)",
    category: "Playback",
    description: "Dispara 3 executors em sequência com pequenos delays.",
    lines: [
      { text: "Go+ Executor <EXEC1>", info: "Ex.: 201", delay: 0 },
      { text: "Go+ Executor <EXEC2>", info: "Ex.: 202", delay: 0.2 },
      { text: "Go+ Executor <EXEC3>", info: "Ex.: 203", delay: 0.2 },
    ],
  },
  {
    id: "store-group-with-label",
    title: "Store Group + Label",
    category: "Store/Update",
    description: "Armazena e já nomeia. Overwrite ligado por padrão.",
    lines: [
      { text: "Store Group <GROUP> /o", info: "Ex.: 10" },
      { text: "Label Group <GROUP> \"<NOME>\"", info: "Ex.: Front Wash" },
    ],
  },
  {
    id: "update-preset-merge",
    title: "Update Preset (merge)",
    category: "Store/Update",
    description: "Atualiza preset mantendo dados existentes (/m).",
    lines: [{ text: "Update Preset <PRESET> /m", info: "Ex.: 4.1" }],
  },
  {
    id: "safe-pre-show-clean",
    title: "Pre-show Clean (seguro)",
    category: "Setup",
    description: "Coloca a mesa num estado conhecido (blind/highlight/solo off + clear).",
    lines: [
      { text: "Off Blind", info: "Modo" },
      { text: "Off Highlight", info: "Modo" },
      { text: "Off Solo", info: "Modo" },
      { text: "ClearAll", info: "Limpa (opcional)", disabled: true },
      { text: "ResetDmxSelection", info: "Seleção DMX" },
    ],
  },
  {
    id: "prompt-at-preset",
    title: "Receita interativa (@): At Preset",
    category: "Util",
    description: "Exemplo do manual: segura para o usuário escolher o preset.",
    lines: [{ text: "At Preset @", info: "Vai esperar você escolher o Preset" }],
  },
];
