/*
Export de texto (colável) para referência
*/

import type { Macro } from "@/lib/project";

export function macroToText(m: Macro) {
  const header = [`# Macro: ${m.name}`, `# Index: ${m.index}`, `# Linhas:`].join("\n");

  const body = (m.lines || [])
    .filter((l) => (l.text ?? "").trim().length > 0)
    .map((l, i) => {
      const flags = [
        l.disabled ? "DISABLED" : null,
        l.delay && l.delay > 0 ? `DELAY=${l.delay}s` : null,
      ]
        .filter(Boolean)
        .join(" ");
      const meta = [flags ? `; ${flags}` : null, l.info ? `; info: ${l.info}` : null]
        .filter(Boolean)
        .join(" ");
      return `${String(i + 1).padStart(2, "0")}: ${l.text}${meta ? " " + meta : ""}`;
    })
    .join("\n");

  return `${header}\n${body}\n`;
}

export function projectToText(macros: Macro[]) {
  return macros
    .slice()
    .sort((a, b) => (a.index || 1) - (b.index || 1))
    .map((m) => macroToText(m))
    .join("\n\n");
}
