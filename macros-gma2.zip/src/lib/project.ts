/*
Núcleo de domínio: Projeto de macros (múltiplas macros)
*/

import { nanoid } from "nanoid";

export type MacroLine = {
  id: string;
  text: string;
  info?: string;
  delay?: number;
  disabled?: boolean;
};

export type Macro = {
  id: string;
  name: string;
  /** índice 1-based (usado para export/import) */
  index: number;
  lines: MacroLine[];
};

export type MacroProject = {
  id: string;
  title: string;
  createdAtIso: string;
  updatedAtIso: string;
  macros: Macro[];
};

export function createEmptyProject(): MacroProject {
  const now = new Date().toISOString();
  return {
    id: nanoid(),
    title: "Projeto de Macros",
    createdAtIso: now,
    updatedAtIso: now,
    macros: [createMacro({ name: "Minha Macro", index: 1 })],
  };
}

export function createMacro(input?: Partial<Pick<Macro, "name" | "index">>): Macro {
  return {
    id: nanoid(),
    name: input?.name ?? "Nova Macro",
    index: input?.index ?? 1,
    lines: [
      { id: nanoid(), text: "ClearAll", info: "(opcional)", delay: 0, disabled: true },
    ],
  };
}

export function touchProject(p: MacroProject): MacroProject {
  return { ...p, updatedAtIso: new Date().toISOString() };
}
