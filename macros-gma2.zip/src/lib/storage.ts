/*
DESIGN: "Console Brutal" (grandMA vibe)
Arquivo: storage.ts
- Persistência local (localStorage)
*/

const KEY = "gma2-macro-builder:v1";

export function saveLocal(payload: unknown) {
  localStorage.setItem(KEY, JSON.stringify(payload));
}

export function loadLocal<T>(): T | null {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function clearLocal() {
  localStorage.removeItem(KEY);
}
