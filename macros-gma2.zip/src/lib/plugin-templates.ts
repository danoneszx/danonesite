/*
Templates de Plugins (Lua) para grandMA2.
Obs.: No MA2, plugins são Lua 5.3 e tipicamente ficam como plugin_#.lua.
Você pode colar o código no editor de Plugin ou salvar como arquivo.
*/

export type PluginTemplate = {
  id: string;
  title: string;
  description: string;
  /** Código Lua (conteúdo do .lua) */
  lua: string;
  /** Sugestão de como executar */
  runHint: string;
};

export const PLUGIN_TEMPLATES: PluginTemplate[] = [
  {
    id: "hello-feedback",
    title: "Hello / Feedback",
    description: "Plugin mínimo: mostra uma mensagem no feedback (útil pra testar ambiente).",
    lua: [
      "return function()",
      "  gma.feedback('hello from plugin')",
      "end",
      "",
    ].join("\n"),
    runHint: "No console: Plugin <ID> (default é Go+).",
  },
  {
    id: "store-show-enumerate",
    title: "SaveShow com contador",
    description:
      "Exemplo clássico de automação: salva show com nome incremental (usa variáveis de usuário).",
    lua: `return function()
  -- Ajuste o nome base e a variável
  local var = 'saveCounter'
  local base = 'SHOW_'
  -- lê variável (se não existir, começa em 1)
  local v = tonumber(gma.show.getvar(var)) or 1
  local name = base .. string.format('%03d', v)
  gma.cmd('SaveShow "' .. name .. '" /nc')
  gma.show.setvar(var, tostring(v + 1))
  gma.feedback('Saved: ' .. name)
end
`, 
    runHint: "Após editar plugin, use Reload/ReloadPlugins e execute: Plugin <ID>.",
  },
  {
    id: "toggle-exectime",
    title: "Toggle Exec Time",
    description:
      "Exemplo rápido de automação via comando: alterna Exec Time usando SpecialMaster.",
    lua: [
      "return function()",
      "  gma.cmd('Toggle SpecialMaster \\\"grandmaster\\\".\\\"exec time\\\"')",
      "end",
      "",
    ].join("\n"),
    runHint: "Execute: Plugin <ID>.",
  },
];
