/*
DESIGN: "Console Brutal" (grandMA vibe)
Arquivo: ai.ts
- Cliente simples para Chat Completions (compatível OpenAI)
- O usuário fornece chave e (opcionalmente) base URL
*/

import { z } from "zod";

export const AiMacroLineSchema = z.object({
  text: z.string(),
  info: z.string().optional().default(""),
  delay: z.number().optional().default(0),
  disabled: z.boolean().optional().default(false),
});

export const AiMacroResponseSchema = z.object({
  name: z.string().optional(),
  lines: z.array(AiMacroLineSchema).min(1),
});

export type AiMacroResponse = z.infer<typeof AiMacroResponseSchema>;

export type AiSettings = {
  apiKey: string;
  baseUrl: string; // ex.: https://api.openai.com/v1
  modelHint?: string; // opcional, não expomos nomes; é só um campo livre
};

const SETTINGS_KEY = "gma2-macro-ai-settings:v1";

export function loadAiSettings(): AiSettings {
  const raw = localStorage.getItem(SETTINGS_KEY);
  if (!raw) {
    return {
      apiKey: "",
      baseUrl: "https://api.openai.com/v1",
      modelHint: "",
    };
  }
  try {
    const parsed = JSON.parse(raw) as Partial<AiSettings>;
    return {
      apiKey: parsed.apiKey ?? "",
      baseUrl: parsed.baseUrl ?? "https://api.openai.com/v1",
      modelHint: parsed.modelHint ?? "",
    };
  } catch {
    return {
      apiKey: "",
      baseUrl: "https://api.openai.com/v1",
      modelHint: "",
    };
  }
}

export function saveAiSettings(s: AiSettings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}

function buildSystemPrompt() {
  return [
    "Você é um assistente especialista em macros do grandMA2 (MA2).",
    "Tarefa: gerar uma macro com linhas de comando para MA2.",
    "Responda SOMENTE com JSON válido, sem markdown.",
    "Formato:",
    '{"name":"string opcional","lines":[{"text":"comando","info":"opcional","delay":0,"disabled":false}] }',
    "Regras:",
    "- Cada linha deve ser um comando típico de MA2 (CLI).",
    "- delay é em segundos (0 se não precisar).",
    "- disabled só true se for um rascunho/alternativa.",
    "- Seja conservador: se não tiver certeza da sintaxe, use comandos simples (ClearAll, Fixture, Group, Page, Go+ Executor, Off Executor, Attribute ...).",
  ].join("\n");
}

export async function generateMacroWithAi(input: {
  intent: string;
  currentName?: string;
  fixturesHint?: string;
  settings: AiSettings;
  signal?: AbortSignal;
}): Promise<AiMacroResponse> {
  const { settings } = input;
  if (!settings.apiKey.trim()) {
    throw new Error("Chave de API não configurada");
  }

  const url = settings.baseUrl.replace(/\/$/, "") + "/chat/completions";

  const userPrompt = [
    "Gere uma macro do grandMA2 conforme a intenção abaixo.",
    input.currentName ? `Nome atual: ${input.currentName}` : "",
    input.fixturesHint ? `Contexto (fixtures): ${input.fixturesHint}` : "",
    "Intenção:",
    input.intent,
  ]
    .filter(Boolean)
    .join("\n");

  // Nota: não fixamos o nome do modelo aqui. Muitos endpoints aceitam um default.
  // Se o provedor exigir, o usuário pode colocar um identificador em modelHint.
  const body: any = {
    model: settings.modelHint?.trim() || undefined,
    messages: [
      { role: "system", content: buildSystemPrompt() },
      { role: "user", content: userPrompt },
    ],
    temperature: 0.2,
  };

  // Remover campos undefined para compatibilidade
  if (!body.model) delete body.model;

  const resp = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${settings.apiKey}`,
    },
    body: JSON.stringify(body),
    signal: input.signal,
  });

  if (!resp.ok) {
    const t = await resp.text();
    throw new Error(`Falha na IA (${resp.status}): ${t.slice(0, 400)}`);
  }

  const json = (await resp.json()) as any;
  const content = json?.choices?.[0]?.message?.content;
  if (typeof content !== "string") {
    throw new Error("Resposta inesperada da IA");
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    throw new Error("A IA não retornou JSON válido. Tente novamente com uma descrição mais objetiva.");
  }

  return AiMacroResponseSchema.parse(parsed);
}
