/*
Componente: Editor Guiado por Comando
*/

import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Plus } from "lucide-react";

import {
  buildGuidedLines,
  type GuidedAction,
  type GuidedActionState,
} from "@/lib/guided-builder";

export function CommandBuilder(props: {
  onInsert: (lines: Array<{ text: string; info?: string }>) => void;
}) {
  const [action, setAction] = useState<GuidedAction>("Go");

  const [state, setState] = useState<GuidedActionState>({
    kind: "Go",
    variant: "Go+",
    target: "Executor",
    executor: "201",
  });

  const preview = useMemo(() => buildGuidedLines(state), [state]);

  function set<K extends GuidedActionState["kind"]>(kind: K, patch: Partial<GuidedActionState>) {
    setState((prev) => ({ ...(prev as any), ...(patch as any), kind }));
  }

  function switchAction(next: GuidedAction) {
    setAction(next);
    if (next === "Go") {
      setState({ kind: "Go", variant: "Go+", target: "Executor", executor: "201" });
    } else if (next === "Fade") {
      setState({ kind: "Fade", seconds: 0.5 });
    } else if (next === "Store") {
      setState({ kind: "Store", object: "Group", id: "10", overwrite: true, merge: false, label: "" });
    } else if (next === "Update") {
      setState({ kind: "Update", object: "Group", id: "10", merge: false });
    }
  }

  return (
    <div className="grid gap-3">
      <div className="grid gap-2">
        <Label>Ação</Label>
        <Select value={action} onValueChange={(v) => switchAction(v as GuidedAction)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Go">Go</SelectItem>
            <SelectItem value="Fade">Fade</SelectItem>
            <SelectItem value="Store">Store</SelectItem>
            <SelectItem value="Update">Update</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {state.kind === "Go" ? (
        <Card className="p-3">
          <div className="grid gap-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="grid gap-2">
                <Label className="text-xs">Variante</Label>
                <Select
                  value={state.variant}
                  onValueChange={(v) => set("Go", { variant: v as any })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Go">Go</SelectItem>
                    <SelectItem value="Go+">Go+</SelectItem>
                    <SelectItem value="GoBack">GoBack</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <Label className="text-xs">Alvo</Label>
                <Select
                  value={state.target}
                  onValueChange={(v) => set("Go", { target: v as any })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Executor">Executor</SelectItem>
                    <SelectItem value="Sequence">Sequence</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {state.target === "Executor" ? (
              <div className="grid gap-2">
                <Label className="text-xs">Executor</Label>
                <Input
                  value={state.executor || ""}
                  onChange={(e) => set("Go", { executor: e.target.value })}
                  className="font-mono"
                  placeholder="Ex.: 201 ou 201.1"
                />
              </div>
            ) : (
              <div className="grid gap-2">
                <div className="grid gap-2">
                  <Label className="text-xs">Sequence</Label>
                  <Input
                    value={state.sequence || ""}
                    onChange={(e) => set("Go", { sequence: e.target.value })}
                    className="font-mono"
                    placeholder="Ex.: 1"
                  />
                </div>
                <div className="grid gap-2">
                  <Label className="text-xs">Cue (opcional)</Label>
                  <Input
                    value={state.cue || ""}
                    onChange={(e) => set("Go", { cue: e.target.value })}
                    className="font-mono"
                    placeholder="Ex.: 10"
                  />
                </div>
              </div>
            )}
          </div>
        </Card>
      ) : null}

      {state.kind === "Fade" ? (
        <Card className="p-3">
          <div className="grid gap-2">
            <Label className="text-xs">Tempo (segundos)</Label>
            <Input
              type="number"
              step={0.1}
              min={0}
              value={state.seconds}
              onChange={(e) => set("Fade", { seconds: parseFloat(e.target.value || "0") || 0 })}
            />
          </div>
        </Card>
      ) : null}

      {state.kind === "Store" ? (
        <Card className="p-3">
          <div className="grid gap-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="grid gap-2">
                <Label className="text-xs">Objeto</Label>
                <Select
                  value={state.object}
                  onValueChange={(v) => set("Store", { object: v as any })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Group">Group</SelectItem>
                    <SelectItem value="Preset">Preset</SelectItem>
                    <SelectItem value="Sequence">Sequence</SelectItem>
                    <SelectItem value="Macro">Macro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label className="text-xs">ID</Label>
                <Input
                  value={state.id}
                  onChange={(e) => set("Store", { id: e.target.value })}
                  className="font-mono"
                  placeholder="Ex.: 10 ou 4.1"
                />
              </div>
            </div>

            <div className="grid gap-2">
              <Label className="text-xs">Label (opcional)</Label>
              <Input
                value={state.label || ""}
                onChange={(e) => set("Store", { label: e.target.value })}
                placeholder="Ex.: Spot Group - odd"
              />
              <div className="text-xs text-muted-foreground">
                Se preencher, o builder adiciona uma linha extra de <span className="font-mono">Label ...</span>.
              </div>
            </div>

            <Separator />

            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold">Opções</div>
                  <div className="text-xs text-muted-foreground">/o overwrite, /m merge</div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">Overwrite (/o)</div>
                <Switch checked={state.overwrite} onCheckedChange={(v) => set("Store", { overwrite: v })} />
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">Merge (/m)</div>
                <Switch checked={state.merge} onCheckedChange={(v) => set("Store", { merge: v })} />
              </div>
            </div>
          </div>
        </Card>
      ) : null}

      {state.kind === "Update" ? (
        <Card className="p-3">
          <div className="grid gap-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="grid gap-2">
                <Label className="text-xs">Objeto</Label>
                <Select
                  value={state.object}
                  onValueChange={(v) => set("Update", { object: v as any })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Group">Group</SelectItem>
                    <SelectItem value="Preset">Preset</SelectItem>
                    <SelectItem value="Sequence">Sequence</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label className="text-xs">ID</Label>
                <Input
                  value={state.id}
                  onChange={(e) => set("Update", { id: e.target.value })}
                  className="font-mono"
                  placeholder="Ex.: 10 ou 4.1"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm">Merge (/m)</div>
                <div className="text-xs text-muted-foreground">Se aplicável ao objeto</div>
              </div>
              <Switch checked={state.merge} onCheckedChange={(v) => set("Update", { merge: v })} />
            </div>
          </div>
        </Card>
      ) : null}

      <Card className="p-3">
        <div className="text-xs font-mono text-muted-foreground">PREVIEW</div>
        <pre className="mt-2 rounded-lg border border-border bg-muted p-3 font-mono text-xs overflow-auto">
{preview.map((l) => l.text).join("\n")}
        </pre>
        <div className="mt-2 flex justify-end">
          <Button onClick={() => props.onInsert(preview)}>
            <Plus className="mr-2 h-4 w-4" /> Inserir no editor
          </Button>
        </div>
      </Card>

      <div className="text-xs text-muted-foreground">
        Dica: selecione uma linha no editor para inserir keywords e completar os placeholders.
      </div>
    </div>
  );
}
