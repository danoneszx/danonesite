/*
Componente: Macros por Objetivo (wizard)
*/

import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Plus } from "lucide-react";

import { OBJECTIVES, buildObjectiveLines, type ObjectiveId, type ObjectiveInput } from "@/lib/objectives";

export function ObjectivesBuilder(props: {
  onInsert: (lines: Array<{ text: string; info?: string; delay?: number; disabled?: boolean }>) => void;
}) {
  const [objectiveId, setObjectiveId] = useState<ObjectiveId>("pre_show");

  const [preShow, setPreShow] = useState({
    includeClearAll: true,
    includeResetDmxSelection: true,
    includeOffModes: true,
    masterGrandAt: 100,
  });

  const [blackout, setBlackout] = useState({
    method: "Blackout keyword" as const,
    value: "Toggle" as const,
  });

  const [chase, setChase] = useState({
    executor: "201",
    fadeSeconds: 0.5,
    initialDelay: 0,
    action: "Go+" as const,
  });

  const input: ObjectiveInput = useMemo(() => {
    if (objectiveId === "pre_show") {
      return {
        id: "pre_show",
        includeClearAll: preShow.includeClearAll,
        includeResetDmxSelection: preShow.includeResetDmxSelection,
        includeOffModes: preShow.includeOffModes,
        masterGrandAt: preShow.masterGrandAt,
      };
    }
    if (objectiveId === "blackout") {
      return {
        id: "blackout",
        method: blackout.method,
        value: blackout.value,
      };
    }
    return {
      id: "chase",
      executor: chase.executor,
      fadeSeconds: chase.fadeSeconds,
      initialDelay: chase.initialDelay,
      action: chase.action,
    };
  }, [objectiveId, preShow, blackout, chase]);

  const preview = useMemo(() => buildObjectiveLines(input), [input]);

  return (
    <div className="grid gap-3">
      <div className="grid gap-2">
        <Label>Objetivo</Label>
        <Select value={objectiveId} onValueChange={(v) => setObjectiveId(v as ObjectiveId)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {OBJECTIVES.map((o) => (
              <SelectItem key={o.id} value={o.id}>
                {o.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="text-xs text-muted-foreground">
          {OBJECTIVES.find((o) => o.id === objectiveId)?.description}
        </div>
      </div>

      {objectiveId === "pre_show" ? (
        <Card className="p-3">
          <div className="text-xs font-mono text-muted-foreground">PARÂMETROS</div>
          <div className="mt-2 grid gap-2">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm">Off modos (Blind/Highlight/Solo)</div>
                <div className="text-xs text-muted-foreground">Estado seguro</div>
              </div>
              <Switch checked={preShow.includeOffModes} onCheckedChange={(v) => setPreShow((s) => ({ ...s, includeOffModes: v }))} />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm">ClearAll (opcional)</div>
                <div className="text-xs text-muted-foreground">Vai desabilitado</div>
              </div>
              <Switch checked={preShow.includeClearAll} onCheckedChange={(v) => setPreShow((s) => ({ ...s, includeClearAll: v }))} />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm">ResetDmxSelection</div>
                <div className="text-xs text-muted-foreground">Limpa seleção DMX</div>
              </div>
              <Switch checked={preShow.includeResetDmxSelection} onCheckedChange={(v) => setPreShow((s) => ({ ...s, includeResetDmxSelection: v }))} />
            </div>

            <Separator />

            <div className="grid gap-2">
              <Label className="text-xs">Grandmaster (opcional)</Label>
              <Input
                type="number"
                min={0}
                max={100}
                value={preShow.masterGrandAt}
                onChange={(e) => setPreShow((s) => ({ ...s, masterGrandAt: parseInt(e.target.value || "0", 10) || 0 }))}
              />
              <div className="text-xs text-muted-foreground">0–100</div>
            </div>
          </div>
        </Card>
      ) : null}

      {objectiveId === "blackout" ? (
        <Card className="p-3">
          <div className="text-xs font-mono text-muted-foreground">PARÂMETROS</div>
          <div className="mt-2 grid gap-2">
            <div className="grid gap-2">
              <Label className="text-xs">Método</Label>
              <Select
                value={blackout.method}
                onValueChange={(v) => setBlackout((s) => ({ ...s, method: v as any }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Blackout keyword">Blackout keyword</SelectItem>
                  <SelectItem value="SpecialMaster Grandmaster">SpecialMaster Grandmaster</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label className="text-xs">Ação</Label>
              <Select value={blackout.value} onValueChange={(v) => setBlackout((s) => ({ ...s, value: v as any }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="On">On</SelectItem>
                  <SelectItem value="Off">Off</SelectItem>
                  <SelectItem value="Toggle">Toggle</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>
      ) : null}

      {objectiveId === "chase" ? (
        <Card className="p-3">
          <div className="text-xs font-mono text-muted-foreground">PARÂMETROS</div>
          <div className="mt-2 grid gap-2">
            <div className="grid grid-cols-2 gap-2">
              <div className="grid gap-2">
                <Label className="text-xs">Executor</Label>
                <Input className="font-mono" value={chase.executor} onChange={(e) => setChase((s) => ({ ...s, executor: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label className="text-xs">Ação</Label>
                <Select value={chase.action} onValueChange={(v) => setChase((s) => ({ ...s, action: v as any }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Go+">Go+</SelectItem>
                    <SelectItem value="Off">Off</SelectItem>
                    <SelectItem value="Toggle">Toggle</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="grid gap-2">
                <Label className="text-xs">Fade (s)</Label>
                <Input
                  type="number"
                  step={0.1}
                  min={0}
                  value={chase.fadeSeconds}
                  onChange={(e) => setChase((s) => ({ ...s, fadeSeconds: parseFloat(e.target.value || "0") || 0 }))}
                />
              </div>
              <div className="grid gap-2">
                <Label className="text-xs">Delay inicial (s)</Label>
                <Input
                  type="number"
                  step={0.1}
                  min={0}
                  value={chase.initialDelay}
                  onChange={(e) => setChase((s) => ({ ...s, initialDelay: parseFloat(e.target.value || "0") || 0 }))}
                />
              </div>
            </div>
          </div>
        </Card>
      ) : null}

      <Card className="p-3">
        <div className="text-xs font-mono text-muted-foreground">PREVIEW</div>
        <pre className="mt-2 rounded-lg border border-border bg-muted p-3 font-mono text-xs overflow-auto">
{preview.map((l) => `${l.delay && l.delay > 0 ? `[delay ${l.delay}s] ` : ""}${l.text}`).join("\n")}
        </pre>
        <div className="mt-2 flex justify-end">
          <Button onClick={() => props.onInsert(preview)}>
            <Plus className="mr-2 h-4 w-4" /> Inserir no editor
          </Button>
        </div>
      </Card>

      <div className="text-xs text-muted-foreground">
        Depois de inserir, você pode ajustar qualquer linha manualmente (placeholders, delays, etc.).
      </div>
    </div>
  );
}
