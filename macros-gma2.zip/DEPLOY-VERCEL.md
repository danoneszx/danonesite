# Publicar online (Vercel)

Este projeto é um site React/Vite estático.

## Opção A — Mais simples (GitHub + Vercel)

1. **Crie um repositório no GitHub** (ex.: `gma2-macro-automations`).
2. No seu computador, entre na pasta do projeto e faça commit/push:

- Instale dependências:
  - `pnpm install`
- Rode localmente:
  - `pnpm dev`
- Build:
  - `pnpm build`
- Commit/push:
  - `git add .`
  - `git commit -m "Deploy inicial"`
  - `git push`

3. Vá em **vercel.com** → **Add New… → Project** → selecione o repositório.
4. Configure:
   - **Framework Preset:** Vite
   - **Build Command:** `pnpm build`
   - **Output Directory:** `dist`
5. Clique **Deploy**.

## Opção B — Sem GitHub (Vercel CLI)

1. Instale Vercel CLI:
   - `npm i -g vercel`
2. Na pasta do projeto:
   - `vercel`
3. Configure quando perguntar:
   - Build command: `pnpm build`
   - Output dir: `dist`

## Domínio próprio (opcional)

No painel do projeto na Vercel:
- **Settings → Domains**
- Adicione seu domínio e siga o passo-a-passo de DNS.

## Observações importantes

- O site é **estático** e já está configurado com `base: "./"` no Vite, então funciona bem em deploy.
- Se você usar a **aba IA**, o usuário precisa colar a chave no navegador. O site não guarda chaves no servidor.

## Checklist rápido

- [ ] Abriu no celular e no desktop
- [ ] Export XML baixou corretamente
- [ ] Import XML carregou corretamente
- [ ] Templates/Receitas/Objetivos inserem linhas na macro ativa
